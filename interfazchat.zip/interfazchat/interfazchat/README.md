MANUAL DE USUARIO
Aplicación de chat en Java con sockets e interfaz gráfica Swing
PRESENTACIÓN
Esta aplicación permite que varios usuarios se comuniquen entre sí mediante mensajes privados, usando un servidor central basado en sockets TCP.
El sistema incluye una interfaz gráfica desarrollada con Swing, donde el usuario puede iniciar sesión, conectarse al servidor, ver la lista de usuarios conectados, enviar mensajes privados, activar el modo invisible y recibir notificaciones cuando otros usuarios se conectan o se desconectan.
La aplicación está diseñada para funcionar con varios clientes al mismo tiempo sin congelar la interfaz gráfica.
USUARIOS Y CONTRASEÑAS DISPONIBLES
Al ejecutar el servidor por primera vez, se crea automáticamente un archivo llamado:
usuarios.txt
Ese archivo contiene los siguientes usuarios de prueba:
Usuario: admin
Contraseña: admin123
Usuario: usuario1
Contraseña: pass1
Usuario: usuario2
Contraseña: pass2
También puedes agregar más usuarios editando el archivo usuarios.txt con el siguiente formato:
usuario:contraseña
Ejemplo:
juan:clave123
maria:secreto
Importante: después de agregar usuarios manualmente, debes reiniciar el servidor para que los reconozca.
REQUISITOS PREVIOS
Para ejecutar la aplicación se necesita:
Java JDK 8 o superior.
Terminal o símbolo del sistema.
Puerto 5000 disponible.
Varios clientes pueden ejecutarse en la misma computadora o en equipos distintos dentro de una red local.
Para verificar si Java está instalado, ejecuta:
java -version
También puedes comprobar el compilador con:
javac -version
INSTALACIÓN Y COMPILACIÓN
Coloca los siguientes archivos en una misma carpeta:
Servidor.java
ClienteHandler.java
Cliente.java
LoginWindow.java
ChatWindow.java
Abre una terminal dentro de esa carpeta y compila todos los archivos con:
javac *.java
Si la compilación es correcta, se generarán archivos .class.
EJECUCIÓN DEL SERVIDOR
Primero debes ejecutar el servidor.
En la terminal escribe:
java Servidor
Si todo funciona correctamente, verás mensajes similares a:
Servidor iniciado en puerto 5000
Usuarios cargados: 3
Esto indica que el servidor ya está esperando conexiones de los clientes.
EJECUCIÓN DEL CLIENTE
Para abrir un cliente, ejecuta en otra terminal:
java Cliente
Se mostrará la ventana de inicio de sesión.
Puedes abrir varios clientes al mismo tiempo para simular distintos usuarios conectados.
VENTANA DE INICIO DE SESIÓN
La ventana de login contiene los siguientes campos:
Servidor
Puerto
Usuario
Contraseña
Botón Iniciar Sesión
Para conectarte desde la misma computadora donde está el servidor, usa:
Servidor: localhost
Puerto: 5000
Usuario: usuario1
Contraseña: pass1
Luego presiona el botón:
Iniciar Sesión
También puedes presionar Enter desde el campo de contraseña.
[Insertar captura de pantalla de la ventana de inicio de sesión]
Figura 1. Ventana de inicio de sesión.
ERRORES POSIBLES EN EL INICIO DE SESIÓN
Si el usuario o la contraseña son incorrectos, se mostrará:
Credenciales incorrectas
Si el usuario ya está conectado en otra sesión, se mostrará:
Sesión duplicada
Si el servidor no está ejecutándose o no se puede alcanzar, se mostrará:
No se pudo conectar al servidor
En esos casos, revisa:
Que el servidor esté activo.
Que el puerto sea 5000.
Que el usuario exista en usuarios.txt.
Que la contraseña esté escrita correctamente.
Que no haya un usuario duplicado conectado.
[Insertar captura de pantalla mostrando un error de login]
Figura 2. Mensaje de error en el inicio de sesión.
VENTANA PRINCIPAL DEL CHAT
Después de iniciar sesión correctamente, se abre la ventana principal del chat.
Esta ventana contiene:
Barra superior con el estado de conexión.
Botón Modo Invisible.
Área de conversación con historial desplazable.
Lista de usuarios conectados.
Campo de texto para escribir mensajes.
Botón Enviar.
La interfaz muestra inicialmente:
● Conectado
Cuando el usuario pierde conexión, se muestra:
● Desconectado
[Insertar captura de pantalla de la ventana principal del chat]
Figura 3. Ventana principal del chat.
LISTA DE USUARIOS CONECTADOS
En el lado derecho de la ventana aparece la lista de usuarios conectados.
Esta lista permite:
Ver qué usuarios están disponibles.
Seleccionar un destinatario haciendo clic sobre su nombre.
Actualizarse automáticamente cuando alguien entra o sale del chat.
Cuando un usuario se conecta, los demás reciben una notificación como:
→ usuario2 se ha conectado
Cuando un usuario se desconecta, los demás reciben:
← usuario1 se ha desconectado
CÓMO ENVIAR UN MENSAJE PRIVADO
Para enviar un mensaje privado, sigue estos pasos:
Selecciona un usuario de la lista de usuarios conectados.
Escribe el mensaje en el campo de texto inferior.
Presiona Enter o haz clic en el botón Enviar.
El mensaje será enviado únicamente al destinatario seleccionado.
En la ventana del emisor se verá algo como:
[14:30] Para usuario2: Hola, ¿cómo estás?
En la ventana del receptor se verá:
[14:30] usuario1: Hola, ¿cómo estás?
De esta forma se distingue quién envió el mensaje y quién lo recibió.
[Insertar captura de pantalla con un mensaje privado enviado]
Figura 4. Envío de mensaje privado entre usuarios.
MODO INVISIBLE
El modo invisible permite que un usuario no aparezca en la lista de usuarios conectados de los demás.
Sin embargo, el usuario invisible:
Sí permanece conectado al servidor.
Sí puede enviar mensajes.
Sí puede recibir mensajes.
No aparece en la lista pública de usuarios conectados.
Para activarlo, haz clic en el botón:
Modo Invisible
Cuando se activa, el sistema muestra:
Modo invisible activado
Para desactivarlo, vuelve a presionar el mismo botón.
El sistema mostrará:
Modo invisible desactivado
[Insertar captura de pantalla mostrando el modo invisible activado]
Figura 5. Activación del modo invisible.
GESTIÓN DE DESCONEXIONES
Cuando un cliente cierra la ventana o pierde la conexión, el servidor elimina al usuario de la lista de conectados y notifica a los demás usuarios.
Los otros clientes verán un mensaje como:
← usuario1 se ha desconectado
Esto permite saber cuándo un usuario abandona el chat.
Si el usuario vuelve a conectarse, los demás verán:
→ usuario1 se ha conectado
[Insertar captura de pantalla mostrando una notificación de desconexión]
Figura 6. Notificación de desconexión de un cliente.
PRUEBA RECOMENDADA CON TRES CLIENTES
Para comprobar correctamente el funcionamiento de la aplicación, se recomienda ejecutar el servidor y tres clientes al mismo tiempo.
Paso 1: Abrir una terminal y ejecutar el servidor:
java Servidor
Paso 2: Abrir otra terminal y ejecutar un cliente:
java Cliente
Iniciar sesión con:
usuario1 / pass1
Paso 3: Abrir otra terminal y ejecutar otro cliente:
java Cliente
Iniciar sesión con:
usuario2 / pass2
Paso 4: Abrir otra terminal y ejecutar un tercer cliente:
java Cliente
Iniciar sesión con:
admin / admin123
Pruebas sugeridas:
Enviar un mensaje de usuario1 a usuario2.
Enviar un mensaje de admin a usuario1.
Verificar que usuario2 no reciba mensajes dirigidos a otro usuario.
Activar el modo invisible en usuario2.
Comprobar que usuario2 desaparece de la lista de los demás.
Enviar un mensaje a usuario2 aunque no aparezca visible.
Confirmar que usuario2 recibe el mensaje.
Cerrar un cliente y observar la notificación de desconexión en los demás.
CONEXIÓN DESDE OTRAS COMPUTADORAS
Si los clientes están en otras máquinas dentro de la misma red local, deben usar la dirección IP del computador donde está el servidor.
Para averiguar la IP en Windows:
ipconfig
Busca una dirección similar a:
IPv4 Address: 192.168.1.10
Para averiguar la IP en Linux o macOS:
ifconfig
o:
ip addr
Luego, en la ventana de login del cliente, escribe:
Servidor: 192.168.1.10
Puerto: 5000
Importante: el firewall del servidor debe permitir conexiones entrantes por el puerto 5000.
SOLUCIÓN DE PROBLEMAS
Problema: el servidor no inicia.
Posible causa: el puerto 5000 ya está ocupado.
Solución: cierra otros programas que usen ese puerto o modifica el puerto en el archivo Servidor.java.
Ejemplo:
private static final int PUERTO = 5001;
Si cambias el puerto, también debes usar ese mismo puerto en el cliente.
Problema: el cliente no se conecta.
Soluciones:
Verifica que el servidor esté ejecutándose.
Confirma que la dirección del servidor sea correcta.
Revisa que el puerto sea 5000.
Comprueba que el firewall no bloquee la conexión.
Problema: aparece “Credenciales incorrectas”.
Soluciones:
Revisa que el usuario exista en usuarios.txt.
Verifica que la contraseña sea exacta.
Asegúrate de que el archivo tenga el formato correcto:
usuario:contraseña
No uses espacios alrededor de los dos puntos.
Incorrecto:
usuario1 : pass1
Correcto:
usuario1:pass1
Problema: aparece “Sesión duplicada”.
Solución:
Ese usuario ya está conectado.
Cierra la sesión anterior o usa otro usuario distinto.
Problema: no se ven usuarios en la lista.
Soluciones:
Verifica que haya otros clientes conectados.
Revisa que el servidor esté funcionando.
Recuerda que un usuario en modo invisible no aparecerá en la lista de los demás.
NOTAS IMPORTANTES
Las contraseñas se guardan en texto plano en usuarios.txt solo con fines académicos.
En una aplicación real, las contraseñas deberían almacenarse cifradas o mediante hash.
El servidor maneja varios clientes simultáneamente usando hilos.
La interfaz gráfica no se congela porque la recepción de mensajes se realiza en un hilo separado.
Los mensajes privados se entregan únicamente al destinatario elegido.
El modo invisible oculta al usuario en la lista pública, pero no impide que envíe o reciba mensajes.
