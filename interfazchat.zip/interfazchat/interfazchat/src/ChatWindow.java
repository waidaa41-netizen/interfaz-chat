// ChatWindow.java
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ChatWindow extends JFrame {
    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String usuario;
    
    private JTextArea txtChat;
    private JTextField txtMensaje;
    private JButton btnEnviar;
    private JList<String> lstUsuarios;
    private DefaultListModel<String> modeloUsuarios;
    private JLabel lblEstado;
    private JToggleButton btnInvisible;
    private String destinatarioActual = null;
    
    public ChatWindow(Socket socket, BufferedReader in, PrintWriter out, String usuario) {
        this.socket = socket;
        this.in = in;
        this.out = out;
        this.usuario = usuario;
        
        setTitle("Chat - " + usuario);
        setSize(1000, 1000);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initComponents();
        iniciarReceptorMensajes();
        solicitarListaUsuarios();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(new Color(245, 245, 245));
        
        // Panel superior con estado e invisible
        JPanel panelSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelSuperior.setBackground(new Color(70, 130, 180));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        lblEstado = new JLabel("● Conectado");
        lblEstado.setForeground(Color.WHITE);
        lblEstado.setFont(new Font("Arial", Font.BOLD, 14));
        panelSuperior.add(lblEstado);
        
        panelSuperior.add(Box.createHorizontalStrut(20));
        
        btnInvisible = new JToggleButton("Modo Invisible");
        btnInvisible.setFont(new Font("Arial", Font.PLAIN, 12));
        btnInvisible.setBackground(new Color(255, 165, 0));
        btnInvisible.setForeground(Color.WHITE);
        btnInvisible.setFocusPainted(false);
        btnInvisible.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleInvisible();
            }
        });
        panelSuperior.add(btnInvisible);
        
        add(panelSuperior, BorderLayout.NORTH);
        
        // Panel central con chat y lista de usuarios
        JPanel panelCentral = new JPanel(new BorderLayout(10, 0));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelCentral.setBackground(Color.WHITE);
        
        // Área de chat
        txtChat = new JTextArea();
        txtChat.setEditable(false);
        txtChat.setFont(new Font("Arial", Font.PLAIN, 14));
        txtChat.setLineWrap(true);
        txtChat.setWrapStyleWord(true);
        txtChat.setBackground(new Color(250, 250, 250));
        
        JScrollPane scrollChat = new JScrollPane(txtChat);
        scrollChat.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panelCentral.add(scrollChat, BorderLayout.CENTER);
        
        // Lista de usuarios
        modeloUsuarios = new DefaultListModel<>();
        lstUsuarios = new JList<>(modeloUsuarios);
        lstUsuarios.setFont(new Font("Arial", Font.PLAIN, 13));
        lstUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        lstUsuarios.setBackground(new Color(240, 240, 240));
        lstUsuarios.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            @Override
            public void valueChanged(javax.swing.event.ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    String seleccionado = lstUsuarios.getSelectedValue();
                    if (seleccionado != null) {
                        destinatarioActual = seleccionado;
                        txtMensaje.requestFocus();
                    }
                }
            }
        });
        
        JScrollPane scrollUsuarios = new JScrollPane(lstUsuarios);
        scrollUsuarios.setPreferredSize(new Dimension(180, 0));
        scrollUsuarios.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200)),
            "Usuarios Conectados",
            TitledBorder.LEFT,
            TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 12)
        ));
        panelCentral.add(scrollUsuarios, BorderLayout.EAST);
        
        add(panelCentral, BorderLayout.CENTER);
        
        // Panel inferior con campo de texto y botón
        JPanel panelInferior = new JPanel(new BorderLayout(5, 0));
        panelInferior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelInferior.setBackground(new Color(245, 245, 245));
        
        txtMensaje = new JTextField();
        txtMensaje.setFont(new Font("Arial", Font.PLAIN, 14));
        txtMensaje.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensaje();
            }
        });
        panelInferior.add(txtMensaje, BorderLayout.CENTER);
        
        btnEnviar = new JButton("Enviar");
        btnEnviar.setFont(new Font("Arial", Font.BOLD, 10));
        btnEnviar.setBackground(new Color(100, 120, 180));
        btnEnviar.setForeground(Color.WHITE);
        btnEnviar.setFocusPainted(false);
        btnEnviar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enviarMensaje();
            }
        });
        panelInferior.add(btnEnviar, BorderLayout.EAST);
        
        add(panelInferior, BorderLayout.SOUTH);
    }
    
    private void iniciarReceptorMensajes() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String linea;
                    while ((linea = in.readLine()) != null) {
                        procesarMensaje(linea);
                    }
                } catch (IOException e) {
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            lblEstado.setText("● Desconectado");
                            lblEstado.setForeground(new Color(255, 50, 30));
                            agregarMensajeSistema("Conexión cerrada");
                        }
                    });
                }
            }
        }).start();
    }
    
    private void procesarMensaje(String mensaje) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                if (mensaje.startsWith("MESSAGE ")) {
                    String contenido = mensaje.substring(8);
                    int indice = contenido.indexOf(":");
                    if (indice > 0) {
                        String remitente = contenido.substring(0, indice);
                        String texto = contenido.substring(indice + 1);
                        agregarMensajeRecibido(remitente, texto);
                    }
                } else if (mensaje.startsWith("USER_LIST ")) {
                    String lista = mensaje.substring(10);
                    actualizarListaUsuarios(lista.split(","));
                } else if (mensaje.startsWith("USER_JOINED ")) {
                    String usuarioNuevo = mensaje.substring(12);
                    agregarMensajeSistema("→ " + usuarioNuevo + " se ha conectado");
                    solicitarListaUsuarios();
                } else if (mensaje.startsWith("USER_LEFT ")) {
                    String usuarioSalio = mensaje.substring(10);
                    agregarMensajeSistema("← " + usuarioSalio + " se ha desconectado");
                    solicitarListaUsuarios();
                } else if (mensaje.startsWith("INVISIBLE_STATUS ")) {
                    String estado = mensaje.substring(17);
                    if (estado.equals("ON")) {
                        agregarMensajeSistema("Modo invisible activado");
                    } else {
                        agregarMensajeSistema("Modo invisible desactivado");
                    }
                } else if (mensaje.startsWith("ERROR:")) {
                    String error = mensaje.substring(6);
                    agregarMensajeSistema("Error: " + error);
                }
            }
        });
    }
    
    private void enviarMensaje() {
        String texto = txtMensaje.getText().trim();
        if (texto.isEmpty()) {
            return;
        }
        
        if (destinatarioActual == null) {
            agregarMensajeSistema("Seleccione un destinatario de la lista");
            return;
        }
        
        out.println("MESSAGE " + destinatarioActual + ":" + texto);
        agregarMensajeEnviado(destinatarioActual, texto);
        txtMensaje.setText("");
    }
    
    private void solicitarListaUsuarios() {
        out.println("LIST");
    }
    
    private void toggleInvisible() {
        out.println("INVISIBLE");
    }
    
    private void actualizarListaUsuarios(String[] usuarios) {
        modeloUsuarios.clear();
        for (String usuario : usuarios) {
            if (!usuario.isEmpty()) {
                modeloUsuarios.addElement(usuario);
            }
        }
    }
    
    private void agregarMensajeRecibido(String remitente, String mensaje) {
        String hora = new SimpleDateFormat("HH:mm").format(new Date());
        txtChat.append("[" + hora + "] " + remitente + ": " + mensaje + "\n");
        txtChat.setCaretPosition(txtChat.getDocument().getLength());
    }
    
    private void agregarMensajeEnviado(String destinatario, String mensaje) {
        String hora = new SimpleDateFormat("HH:mm").format(new Date());
        txtChat.append("[" + hora + "] Para " + destinatario + ": " + mensaje + "\n");
        txtChat.setCaretPosition(txtChat.getDocument().getLength());
    }
    
    private void agregarMensajeSistema(String mensaje) {
        String hora = new SimpleDateFormat("HH:mm").format(new Date());
        txtChat.append("[" + hora + "] " + mensaje + "\n");
        txtChat.setCaretPosition(txtChat.getDocument().getLength());
    }
}