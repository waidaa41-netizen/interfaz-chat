// ClienteHandler.java
import java.io.*;
import java.net.*;

public class ClienteHandler implements Runnable {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String usuario;
    private boolean invisible = false;
    private boolean autenticado = false;
    
    public ClienteHandler(Socket socket) {
        this.socket = socket;
    }
    
    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            
            // Esperar autenticación
            String linea;
            while ((linea = in.readLine()) != null) {
                if (linea.startsWith("LOGIN ")) {
                    procesarLogin(linea.substring(6));
                    if (autenticado) {
                        break;
                    }
                } else {
                    enviarMensaje("ERROR:Debe autenticarse primero");
                }
            }
            
            if (!autenticado) {
                socket.close();
                return;
            }
            
            // Notificar conexión
            Servidor.notificarConexion(usuario);
            
            // Procesar mensajes
            while ((linea = in.readLine()) != null) {
                procesarComando(linea);
            }
            
        } catch (IOException e) {
            System.out.println("Cliente desconectado: " + usuario);
        } finally {
            if (usuario != null) {
                Servidor.eliminarCliente(usuario);
                Servidor.notificarDesconexion(usuario);
            }
            cerrarConexion();
        }
    }
    
    private void procesarLogin(String credenciales) {
        String[] partes = credenciales.split(":");
        if (partes.length != 2) {
            enviarMensaje("LOGIN_FAIL:Formato incorrecto");
            return;
        }
        
        String user = partes[0];
        String pass = partes[1];
        
        if (Servidor.usuarioYaConectado(user)) {
            enviarMensaje("LOGIN_FAIL:Sesión duplicada");
            return;
        }
        
        if (Servidor.validarCredenciales(user, pass)) {
            this.usuario = user;
            this.autenticado = true;
            Servidor.registrarCliente(usuario, this);
            enviarMensaje("LOGIN_OK");
            System.out.println("Usuario autenticado: " + usuario);
        } else {
            enviarMensaje("LOGIN_FAIL:Credenciales incorrectas");
        }
    }
    
    private void procesarComando(String comando) {
        if (comando.startsWith("MESSAGE ")) {
            String contenido = comando.substring(8);
            int indice = contenido.indexOf(":");
            if (indice > 0) {
                String destinatario = contenido.substring(0, indice);
                String mensaje = contenido.substring(indice + 1);
                Servidor.enviarMensajePrivado(destinatario, usuario, mensaje);
            }
        } else if (comando.equals("LIST")) {
            java.util.List<String> lista = Servidor.obtenerListaUsuarios(usuario);
            enviarMensaje("USER_LIST " + String.join(",", lista));
        } else if (comando.equals("INVISIBLE")) {
            invisible = !invisible;
            enviarMensaje("INVISIBLE_STATUS " + (invisible ? "ON" : "OFF"));
            System.out.println("Usuario " + usuario + " ahora es " + (invisible ? "invisible" : "visible"));
        } else if (comando.equals("QUIT")) {
            cerrarConexion();
        }
    }
    
    public void enviarMensaje(String mensaje) {
        if (out != null) {
            out.println(mensaje);
        }
    }
    
    public boolean esInvisible() {
        return invisible;
    }
    
    private void cerrarConexion() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            System.err.println("Error al cerrar conexión: " + e.getMessage());
        }
    }
}