// Servidor.java
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class Servidor {
    private static final int PUERTO = 5000;
    private static Map<String, ClienteHandler> clientesConectados = new ConcurrentHashMap<>();
    private static Map<String, String> usuariosRegistrados = new HashMap<>();
    
    public static void main(String[] args) {
        cargarUsuarios();
        
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor iniciado en puerto " + PUERTO);
            
            while (true) {
                Socket clienteSocket = serverSocket.accept();
                System.out.println("Nueva conexión desde: " + clienteSocket.getInetAddress());
                new Thread(new ClienteHandler(clienteSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Error en el servidor: " + e.getMessage());
        }
    }
    
    private static void cargarUsuarios() {
        try (BufferedReader br = new BufferedReader(new FileReader("usuarios.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(":");
                if (partes.length == 2) {
                    usuariosRegistrados.put(partes[0], partes[1]);
                }
            }
            System.out.println("Usuarios cargados: " + usuariosRegistrados.size());
        } catch (IOException e) {
            System.err.println("Error al cargar usuarios: " + e.getMessage());
            System.out.println("Creando archivo de usuarios por defecto...");
            crearUsuariosPorDefecto();
        }
    }
    
    private static void crearUsuariosPorDefecto() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("usuarios.txt"))) {
            pw.println("admin:admin123");
            pw.println("usuario1:pass1");
            pw.println("usuario2:pass2");
            usuariosRegistrados.put("admin", "admin123");
            usuariosRegistrados.put("usuario1", "pass1");
            usuariosRegistrados.put("usuario2", "pass2");
            System.out.println("Archivo usuarios.txt creado con usuarios por defecto");
        } catch (IOException e) {
            System.err.println("Error al crear archivo de usuarios: " + e.getMessage());
        }
    }
    
    public static boolean validarCredenciales(String usuario, String password) {
        String passGuardada = usuariosRegistrados.get(usuario);
        return passGuardada != null && passGuardada.equals(password);
    }
    
    public static boolean usuarioYaConectado(String usuario) {
        return clientesConectados.containsKey(usuario);
    }
    
    public static void registrarCliente(String usuario, ClienteHandler handler) {
        clientesConectados.put(usuario, handler);
    }
    
    public static void eliminarCliente(String usuario) {
        clientesConectados.remove(usuario);
    }
    
    public static void enviarMensajePrivado(String destinatario, String remitente, String mensaje) {
        ClienteHandler handler = clientesConectados.get(destinatario);
        if (handler != null) {
            handler.enviarMensaje("MESSAGE " + remitente + ":" + mensaje);
        } else {
            ClienteHandler remitenteHandler = clientesConectados.get(remitente);
            if (remitenteHandler != null) {
                remitenteHandler.enviarMensaje("ERROR:Usuario no encontrado");
            }
        }
    }
    
    public static List<String> obtenerListaUsuarios(String solicitante) {
        List<String> lista = new ArrayList<>();
        ClienteHandler handlerSolicitante = clientesConectados.get(solicitante);
        
        for (Map.Entry<String, ClienteHandler> entry : clientesConectados.entrySet()) {
            String usuario = entry.getKey();
            ClienteHandler handler = entry.getValue();
            
            if (!usuario.equals(solicitante)) {
                if (!handler.esInvisible() || usuario.equals(solicitante)) {
                    lista.add(usuario);
                }
            }
        }
        return lista;
    }
    
    public static void notificarConexion(String usuario) {
        String mensaje = "USER_JOINED " + usuario;
        for (Map.Entry<String, ClienteHandler> entry : clientesConectados.entrySet()) {
            if (!entry.getKey().equals(usuario)) {
                ClienteHandler handler = entry.getValue();
                if (!handler.esInvisible()) {
                    handler.enviarMensaje(mensaje);
                }
            }
        }
    }
    
    public static void notificarDesconexion(String usuario) {
        String mensaje = "USER_LEFT " + usuario;
        for (Map.Entry<String, ClienteHandler> entry : clientesConectados.entrySet()) {
            if (!entry.getKey().equals(usuario)) {
                entry.getValue().enviarMensaje(mensaje);
            }
        }
    }
}