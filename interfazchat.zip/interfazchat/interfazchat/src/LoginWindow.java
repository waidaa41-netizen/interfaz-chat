// LoginWindow.java
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class LoginWindow extends JFrame {
    private JTextField txtServidor;
    private JTextField txtPuerto;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JLabel lblMensaje;
    
    public LoginWindow() {
        setTitle("Bienveido");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("Iniciar Sesión", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);
        
        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        panel.add(new JLabel("Servidor:"), gbc);
        txtServidor = new JTextField("localhost");
        gbc.gridx = 1;
        panel.add(txtServidor, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Puerto:"), gbc);
        txtPuerto = new JTextField("5000");
        gbc.gridx = 1;
        panel.add(txtPuerto, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Usuario:"), gbc);
        txtUsuario = new JTextField();
        gbc.gridx = 1;
        panel.add(txtUsuario, gbc);
        
        gbc.gridx = 0;
        gbc.gridy++;
        panel.add(new JLabel("Contraseña:"), gbc);
        txtPassword = new JPasswordField();
        gbc.gridx = 1;
        panel.add(txtPassword, gbc);
        
        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setBackground(new Color(70, 130, 180));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(15, 5, 5, 5);
        panel.add(btnLogin, gbc);
        
        lblMensaje = new JLabel("", SwingConstants.CENTER);
        lblMensaje.setForeground(Color.RED);
        gbc.gridy++;
        panel.add(lblMensaje, gbc);
        
        add(panel);
        
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                intentarLogin();
            }
        });
        
        txtPassword.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                intentarLogin();
            }
        });
    }
    
    private void intentarLogin() {
        String servidor = txtServidor.getText().trim();
        String puertoStr = txtPuerto.getText().trim();
        String usuario = txtUsuario.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        
        if (servidor.isEmpty() || puertoStr.isEmpty() || usuario.isEmpty() || password.isEmpty()) {
            lblMensaje.setText("Complete todos los campos");
            return;
        }
        
        int puerto;
        try {
            puerto = Integer.parseInt(puertoStr);
        } catch (NumberFormatException e) {
            lblMensaje.setText("Puerto inválido");
            return;
        }
        
        btnLogin.setEnabled(false);
        lblMensaje.setText("Conectando...");
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Socket socket = new Socket(servidor, puerto);
                    PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    
                    out.println("LOGIN " + usuario + ":" + password);
                    String respuesta = in.readLine();
                    
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            if (respuesta != null && respuesta.equals("LOGIN_OK")) {
                                dispose();
                                ChatWindow chatWindow = new ChatWindow(socket, in, out, usuario);
                                chatWindow.setVisible(true);
                            } else {
                                String error = "Error de conexión";
                                if (respuesta != null && respuesta.startsWith("LOGIN_FAIL:")) {
                                    error = respuesta.substring(11);
                                }
                                lblMensaje.setText(error);
                                btnLogin.setEnabled(true);
                                try {
                                    socket.close();
                                } catch (IOException ex) {
                                    ex.printStackTrace();
                                }
                            }
                        }
                    });
                } catch (IOException e) {
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            lblMensaje.setText("No se pudo conectar al servidor");
                            btnLogin.setEnabled(true);
                        }
                    });
                }
            }
        }).start();
    }
}
